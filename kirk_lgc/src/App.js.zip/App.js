import React from "react";
import "./App.css";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      formula1: "",
      formula2: "",
      formula3: "",
      formula4: "",
      formula5: "",
      formula6: "",
      formula7: "",
      textInputIterator: 1,
      //caries state of each textbox
      clickedInputId: null,
      checkboxPipe1: false,
      checkboxPipe2: false,
      checkboxPipe3: false,
      checkboxPipe4: false,
      checkboxPipe5: false,
      checkboxPipe6: false,
      checkboxPipe7: false,
      ruleNumber: "0",
    };
  }

  inputText = (event) => {
    console.log(this.state);
    if (event.target.id === "1") {
      this.setState({ formula1: event.target.value });
    } else if (event.target.id === "2") {
      this.setState({ formula2: event.target.value });
    } else if (event.target.id === "3") {
      this.setState({ formula3: event.target.value });
    } else if (event.target.id === "4") {
      this.setState({ formula4: event.target.value });
    } else if (event.target.id === "5") {
      this.setState({ formula5: event.target.value });
    } else if (event.target.id === "6") {
      this.setState({ formula6: event.target.value });
    } else if (event.target.id === "7") {
      this.setState({ formula7: event.target.value });
    }
  };

  clickOperator = (event) => {
    console.log(event);
    if (this.state.clickedInputId === "1") {
      this.setState({ formula1: this.state.formula1 + event });
    } else if (this.state.clickedInputId === "2") {
      this.setState({ formula2: this.state.formula2 + event });
    } else if (this.state.clickedInputId === "3") {
      this.setState({ formula3: this.state.formula3 + event });
    } else if (this.state.clickedInputId === "4") {
      this.setState({ formula4: this.state.formula4 + event });
    } else if (this.state.clickedInputId === "5") {
      this.setState({ formula5: this.state.formula5 + event });
    } else if (this.state.clickedInputId === "6") {
      this.setState({ formula6: this.state.formula6 + event });
    } else if (this.state.clickedInputId === "7") {
      this.setState({ formula7: this.state.formula7 + event });
    }
  };

  clickPlusButton = () => {
    this.setState({
      textInputIterator: this.state.textInputIterator + 1,
    });
    console.log(this.state);
  };

  clickInput = (event) => {
    console.log(event.target.id);
    this.setState({ clickedInputId: event.target.id });
  };

  clickCheckbox = (event) => {
    console.log(event.target.id);
    if (event.target.id === "1") {
      this.setState({ checkboxPipe1: !this.state.checkboxPipe1 });
    } else if (event.target.id === "2") {
      this.setState({ checkboxPipe2: !this.state.checkboxPipe2 });
    } else if (event.target.id === "3") {
      this.setState({ checkboxPipe3: !this.state.checkboxPipe3 });
    } else if (event.target.id === "4") {
      this.setState({ checkboxPipe4: !this.state.checkboxPipe4 });
    } else if (event.target.id === "5") {
      this.setState({ checkboxPipe5: !this.state.checkboxPipe5 });
    } else if (event.target.id === "6") {
      this.setState({ checkboxPipe6: !this.state.checkboxPipe6 });
    } else if (event.target.id === "7") {
      this.setState({ checkboxPipe7: !this.state.checkboxPipe7 });
    }
  };

  ruleStyle = () => {
    if (
      this.state.checkboxPipe1 ||
      this.state.checkboxPipe2 ||
      this.state.checkboxPipe3 ||
      this.state.checkboxPipe4 ||
      this.state.checkboxPipe5 ||
      this.state.checkboxPipe6 ||
      this.state.checkboxPipe7
    ) {
      return "rgb(28, 184, 41)";
    } else {
      return "black";
    }
  };

  ruleBox = (event) => {
    //console.log(event.target.id)
    this.setState({ ruleNumber: event.target.id });
  };

  render() {
    const inputField = [];
    const formulaArray = [
      this.state.formula1,
      this.state.formula2,
      this.state.formula3,
      this.state.formula4,
      this.state.formula5,
      this.state.formula6,
      this.state.formula7,
    ];
    const checkPipeArray = [
      this.state.checkboxPipe1,
      this.state.checkboxPipe2,
      this.state.checkboxPipe3,
      this.state.checkboxPipe4,
      this.state.checkboxPipe5,
      this.state.checkboxPipe6,
      this.state.checkboxPipe7,
    ];
    for (let index = 1; index <= this.state.textInputIterator; index++) {
      inputField.push(
        <div className="wrap" key={index}>
          <span>{index}.</span>
          <input
            id={index}
            onChange={this.inputText}
            onClick={this.clickInput}
            type="text"
            placeholder="Enter a formula"
            value={formulaArray[index - 1]}
          ></input>
          <div className="checkbox" onClick={this.clickCheckbox} id={index}>
            <span
              id={index}
              style={{
                display: `${checkPipeArray[index - 1] ? "initial" : "none"}`,
              }}
              className="pipe"
            >
              ✔
            </span>
          </div>
        </div>
      );
    }

    if (this.state.ruleNumber === "2") {
      inputField.push(
        <div className="wrap" key={inputField.length + 1}>
          <span>|</span>
        </div>
      );
      inputField.push(
        <div className="wrap" key={inputField.length + 1}>
          <span>{inputField.length}.</span>
          <input
            id={inputField.length}
            onChange={this.inputText}
            onClick={this.clickInput}
            type="text"
            placeholder="Enter a formula"
            value={formulaArray[inputField.length - 1]}
          ></input>
          <div
            className="checkbox"
            onClick={this.clickCheckbox}
            id={inputField.length}
          >
            <span
              id={inputField.length}
              style={{
                display: `${
                  checkPipeArray[inputField.length - 1] ? "initial" : "none"
                }`,
              }}
              className="pipe"
            >
              ✔
            </span>
          </div>
        </div>
      );
    }
    //establish button text
    return (
      <div className="App">
        <h1>The Kirk Tool for Logic Trees</h1>
        <div className="left">
          <h2>Logical Operators</h2>
          <div className="operator-btn" onClick={() => this.clickOperator("¬")}>
            ¬
          </div>
          <div className="operator-btn" onClick={() => this.clickOperator("∧")}>
            ∧
          </div>
          <div className="operator-btn" onClick={() => this.clickOperator("∨")}>
            ∨
          </div>
          <div className="operator-btn" onClick={() => this.clickOperator("→")}>
            →
          </div>
          <div className="operator-btn" onClick={() => this.clickOperator("↔")}>
            ↔
          </div>
          <div className="operator-btn" onClick={() => this.clickOperator("∀")}>
            ∀
          </div>
          <div className="operator-btn" onClick={() => this.clickOperator("∃")}>
            ∃
          </div>
        </div>
        <div className="middle">
          {inputField}
          <div onClick={this.clickPlusButton} className="operator-btn">
            +
          </div>
        </div>
        <div className="right">
          <h2 style={{ color: this.ruleStyle() }}>Splitting Rule</h2>
          <div
            style={{ border: `2px solid ${this.ruleStyle()}` }}
            id="1"
            onClick={this.ruleBox}
            className="rule-box rbone"
          >
            <div className="q one">/</div>
            <div className="q two">\</div>
            <div className="q three">
              <div id="1" className="operator-btn"></div>
            </div>
            <div className="q four">
              <div id="1" className="operator-btn"></div>
            </div>
          </div>
          <h2 style={{ color: this.ruleStyle() }}>Stacking Rule</h2>
          <div
            style={{ border: `2px solid ${this.ruleStyle()}` }}
            id="2"
            onClick={this.ruleBox}
            className="rule-box rbtwo"
          >
            <div className="t one">|</div>
            <div className="t two">
              <div id="2" className="operator-btn"></div>
            </div>
            <div className="t three">
              <div id="2" className="operator-btn"></div>
            </div>
          </div>
          <h2 style={{ color: this.ruleStyle() }}>Branch Closure</h2>
          <div
            style={{ border: `2px solid ${this.ruleStyle()}` }}
            id="3"
            onClick={this.ruleBox}
            className="rule-box rbthree"
          >
            <div className="t one">
              <div id="3" className="operator-btn"></div>
            </div>
            <div className="t two">
              <div id="3" className="operator-btn"></div>
            </div>
            <div className="t three">✕</div>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
